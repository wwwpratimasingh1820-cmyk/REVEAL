// --- State ---
let currentFileUrl = null;

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Theme immediately
    initTheme();

    // 2. Select DOM Elements safely
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('file-input');
    const browseBtn = document.getElementById('browse-btn');
    const themeToggleBtn = document.getElementById('theme-toggle');
    const backBtn = document.getElementById('back-btn');
    const rawToggle = document.getElementById('raw-toggle');
    const rawBody = document.getElementById('raw-data-container');

    // 3. Attach Event Listeners
    if (browseBtn && fileInput) {
        browseBtn.addEventListener('click', () => {
            fileInput.value = ''; 
            fileInput.click();
        });
        fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));
    }

    if (backBtn) backBtn.addEventListener('click', resetApp);
    if (themeToggleBtn) themeToggleBtn.addEventListener('click', toggleTheme);

    // Drag & Drop
    if (dropzone) {
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
        });
    }

    // Raw Data Toggle
    if (rawToggle && rawBody) {
        rawToggle.addEventListener('click', () => {
            rawBody.classList.toggle('open');
            rawToggle.querySelector('.arrow').textContent = rawBody.classList.contains('open') ? '▲' : '▼';
        });
    }

    console.log("REVEAL App Initialized");
});

// --- Theme Logic ---
function initTheme() {
    try {
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);
    } catch (e) {
        console.warn("Theme init failed (likely privacy settings):", e);
        document.documentElement.setAttribute('data-theme', 'dark');
    }
}

function toggleTheme() {
    try {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        updateThemeIcon(next);
    } catch (e) {
        console.warn("Theme toggle failed:", e);
    }
}

function updateThemeIcon(theme) {
    const themeToggleBtn = document.getElementById('theme-toggle');
    if (!themeToggleBtn) return;
    
    const sun = themeToggleBtn.querySelector('.icon-sun');
    const moon = themeToggleBtn.querySelector('.icon-moon');
    
    if (theme === 'dark') {
        sun.style.display = 'block';
        moon.style.display = 'none';
    } else {
        sun.style.display = 'none';
        moon.style.display = 'block';
    }
}

// --- Core Logic ---

async function handleFile(file) {
    if (!file) return;

    switchView('loading');
    
    // Cleanup previous URL object to prevent memory leaks
    if (currentFileUrl) URL.revokeObjectURL(currentFileUrl);
    currentFileUrl = URL.createObjectURL(file);

    try {
        const isVideo = file.type.startsWith('video');
        
        // 1. Basic File Info
        renderBasicInfo(file, isVideo);

        // 2. Extract Metadata
        let metadata = {};
        
        // exifr works on images AND some video containers (mp4/mov) for XMP/QuickTime
        try {
            if (typeof exifr === 'undefined') {
                throw new Error("Metadata library failed to load. Please check your internet connection.");
            }

            metadata = await exifr.parse(file, {
                // Enable ALL extraction modules
                tiff: true,
                xmp: true,
                icc: true,
                iptc: true,
                exif: true,
                gps: true,
                ifd0: true,
                ifd1: true,
                interop: true,
                makerNote: true,
                userComment: true,
                multiSegment: true,
                // Video specific
                mergeOutput: true,
                reviveValues: true // Try to parse strings/numbers
            });
        } catch (e) {
            console.warn("exifr parsing warning:", e);
        }

        // If video, get native props
        let videoMeta = {};
        if (isVideo) {
            videoMeta = await getVideoNativeMetadata(file);
            metadata = { ...metadata, ...videoMeta };
        }

        // 3. Render Data
        renderMetadata(metadata || {}, file);
        
        // 4. AI Detection
        runAIDetection(metadata || {}, file);

        switchView('results');

    } catch (error) {
        console.error(error);
        alert("Error parsing file. It might be corrupted or an unsupported format.");
        switchView('upload');
    }
}

function renderBasicInfo(file, isVideo) {
    document.getElementById('res-filename').textContent = file.name;
    document.getElementById('res-type').textContent = file.type || 'Unknown';
    document.getElementById('res-size').textContent = formatBytes(file.size);

    const container = document.getElementById('thumbnail-container');
    container.innerHTML = '';

    if (isVideo) {
        const video = document.createElement('video');
        video.src = currentFileUrl;
        video.muted = true;
        video.preload = 'metadata';
        // Seek to 1st second to get a frame
        video.currentTime = 0.5; 
        container.appendChild(video);
    } else {
        const img = document.createElement('img');
        img.src = currentFileUrl;
        container.appendChild(img);
    }
}

function renderMetadata(data, file) {
    const cameraList = document.getElementById('camera-data');
    const techList = document.getElementById('tech-data');
    const gpsList = document.getElementById('gps-data');
    const rawJson = document.getElementById('raw-json');

    // Clear previous
    cameraList.innerHTML = '';
    techList.innerHTML = '';
    gpsList.innerHTML = '';

    // Helpers
    const addRow = (container, label, value) => {
        if (value === undefined || value === null || value === '') return;
        // Format dates
        if (value instanceof Date) value = value.toLocaleString();
        
        const row = document.createElement('div');
        row.className = 'data-row';
        row.innerHTML = `<span class="data-label">${label}</span><span class="data-value">${value}</span>`;
        container.appendChild(row);
    };

    // --- Camera / Device ---
    addRow(cameraList, 'Make', data.Make);
    addRow(cameraList, 'Model', data.Model);
    addRow(cameraList, 'Lens', data.LensModel || data.Lens);
    addRow(cameraList, 'Serial Number', data.SerialNumber || data.BodySerialNumber);
    addRow(cameraList, 'Owner Name', data.OwnerName);
    addRow(cameraList, 'Software', data.Software);
    addRow(cameraList, 'Artist', data.Artist || data.creator);
    addRow(cameraList, 'Copyright', data.Copyright || data.rights);

    if (cameraList.children.length === 0) {
        cameraList.innerHTML = '<div class="data-row"><span class="data-label">No device data found</span></div>';
    }

    // --- Technical ---
    // Prefer native video dims if available, else EXIF
    const width = data.videoWidth || data.ExifImageWidth || data.ImageWidth;
    const height = data.videoHeight || data.ExifImageHeight || data.ImageHeight;
    
    if (width && height) addRow(techList, 'Dimensions', `${width} x ${height}`);
    if (data.durationSec) addRow(techList, 'Duration', formatDuration(data.durationSec));
    
    addRow(techList, 'ISO', data.ISO);
    addRow(techList, 'F-Stop', data.FNumber ? `f/${data.FNumber}` : null);
    addRow(techList, 'Exposure', data.ExposureTime ? `${data.ExposureTime}s` : null);
    addRow(techList, 'Focal Length', data.FocalLength ? `${data.FocalLength}mm` : null);
    addRow(techList, 'Orientation', data.Orientation);
    addRow(techList, 'Flash', data.Flash);
    addRow(techList, 'White Balance', data.WhiteBalance);
    addRow(techList, 'Metering Mode', data.MeteringMode);
    addRow(techList, 'Date Created', data.DateTimeOriginal || data.CreateDate || file.lastModifiedDate);
    addRow(techList, 'Date Modified', data.ModifyDate || file.lastModifiedDate);
    addRow(techList, 'Color Space', data.ColorSpaceData);
    addRow(techList, 'Color Profile', data.ProfileDescription || data.ICCProfileName);
    addRow(techList, 'Bit Depth', data.BitsPerSample ? data.BitsPerSample.toString() : null);
    addRow(techList, 'Compression', data.Compression);
    
    // Advanced Image Data
    if (data.History) {
        addRow(techList, 'Editing History', 'Present (See Raw Data)');
    }
    
    // Video Specifics (if available via exifr or native)
    if (data.MIMEType && data.MIMEType.startsWith('video')) {
        addRow(techList, 'Handler', data.HandlerDescription || data.Handler);
        addRow(techList, 'Compressor', data.CompressorName);
        addRow(techList, 'Video Frame Rate', data.VideoFrameRate);
    }

    // Browser Limitation Note for Video
    if (file.type.startsWith('video')) {
        addRow(techList, 'Note', 'Some container metadata may be inaccessible in-browser.');
    }
    
    addRow(techList, 'MIME Type', data.MIMEType || file.type);

    if (techList.children.length === 0) {
        techList.innerHTML = '<div class="data-row"><span class="data-label">No technical data found</span></div>';
    }

    // --- GPS ---
    if (data.latitude && data.longitude) {
        addRow(gpsList, 'Latitude', data.latitude.toFixed(6));
        addRow(gpsList, 'Longitude', data.longitude.toFixed(6));
        // Generate Google Maps Link
        const link = document.createElement('a');
        link.href = `https://www.google.com/maps?q=${data.latitude},${data.longitude}`;
        link.target = "_blank";
        link.style.color = "var(--success)";
        link.style.fontSize = "0.8rem";
        link.style.display = "block";
        link.style.marginTop = "8px";
        link.textContent = "View on Maps ↗";
        gpsList.appendChild(link);
    } else {
        gpsList.innerHTML = '<div class="data-row"><span class="data-label">No GPS coordinates embedded</span></div>';
    }

    // --- Raw Data ---
    // Use a custom replacer to handle binary data and BigInts without hiding keys
    const replacer = (key, value) => {
        if (value instanceof Uint8Array || value instanceof ArrayBuffer) {
            return `[Binary Data: ${value.byteLength} bytes]`;
        }
        if (typeof value === 'bigint') return value.toString();
        return value;
    };
    rawJson.textContent = JSON.stringify(data, replacer, 2);
}

// --- AI Detection Heuristics ---
function runAIDetection(data, file) {
    const section = document.getElementById('ai-section');
    const verdict = document.getElementById('ai-verdict');
    const contextEl = document.getElementById('ai-context');
    const signalsList = document.getElementById('ai-signals');
    const confidenceBar = document.getElementById('ai-confidence-bar');
    
    section.style.display = 'block';
    signalsList.innerHTML = '';
    contextEl.textContent = '';
    
    let score = 0;
    let contextMsg = "";
    let signals = [];
    
    const isVideo = file.type.startsWith('video');
    const hasCamera = data.Make || data.Model;
    const software = (data.Software || "").toLowerCase();
    const creator = (data['dc:creator'] || data.creator || data.Artist || "").toString().toLowerCase();
    const encoder = (data.Handler || data.CompressorName || data.Encoder || "").toLowerCase();

    // --- 1. Strong Signals (Explicit AI Tools) ---
    const aiTools = [
        'midjourney', 'dall-e', 'stable diffusion', 'comfyui', 'automatic1111', 
        'novelai', 'adobe firefly', 'generative', 'bing image creator', 
        'dreamstudio', 'leonardo.ai', 'runway', 'pika', 'luma', 'sora', 'haiper',
        'topaz', 'gigapixel', 'esrgan', 'rife', 'waifu2x', 'upscale',
        'civitai', 'tensor', 'diffusers'
    ];
    
    aiTools.forEach(tool => {
        if (software.includes(tool) || creator.includes(tool) || encoder.includes(tool)) {
            score += 50;
            signals.push(`Metadata explicitly names AI tool: "${tool}".`);
        }
    });

    // --- 2. Medium Signals (Anomalies) ---
    
    // Missing Camera Data in Images
    if (!isVideo && !hasCamera) {
        score += 10;
        signals.push("No camera device information (Make/Model) found.");
    }

    // Video Encoder Checks
    if (isVideo) {
        // Lavf (Libavformat) is standard FFmpeg, but often used in AI generation pipelines
        // If it's the ONLY metadata, it's suspicious.
        if (encoder.includes('lavf') || encoder.includes('ffmpeg')) {
            if (!hasCamera) {
                score += 15;
                signals.push("Video processed with generic encoder (FFmpeg/Lavf) lacking capture data.");
            }
        }
    }

    // Editing Software without Camera Data
    if ((software.includes('photoshop') || software.includes('gimp')) && !hasCamera) {
        score += 10;
        signals.push("Edited with software but missing original camera data.");
    }

    // XMP History Check (Adobe)
    if (data.History && JSON.stringify(data.History).toLowerCase().includes('generate')) {
        score += 20;
        signals.push("Editing history contains 'generate' actions.");
    }

    // --- 3. Inconclusive Check (Stripped Metadata) ---
    const keyCount = Object.keys(data).length;
    const isStripped = keyCount < 6; // Very few tags

    // --- Verdict Logic ---
    verdict.className = 'ai-verdict';
    confidenceBar.className = 'ai-confidence-fill';
    let confidencePercent = 0;

    if (score >= 50) {
        // LIKELY AI
        verdict.textContent = "Likely AI-Generated";
        verdict.classList.add('suspicious');
        confidenceBar.classList.add('high');
        confidencePercent = 95;
        contextMsg = "Strong metadata signatures found matching known generative AI tools.";
    } else if (score >= 20) {
        // POSSIBLY AI
        verdict.textContent = "Possibly AI-Generated";
        verdict.classList.add('warning');
        confidenceBar.classList.add('med');
        confidencePercent = 65;
        contextMsg = "File lacks capture data and shows signs of software processing or upscaling.";
    } else if (isStripped) {
        // STRIPPED -> "May be AI" (Orange) per user request
        verdict.textContent = "Inconclusive / Possible AI";
        verdict.classList.add('warning');
        confidenceBar.classList.add('med');
        confidencePercent = 45;
        contextMsg = "Metadata is heavily stripped. This is common in AI generation, though also in social media.";
    } else if (score > 0) {
        // Minor Indicators -> Orange per user request
        verdict.textContent = "Uncertain / Minor Indicators";
        verdict.classList.add('warning');
        confidenceBar.classList.add('med');
        confidencePercent = 35;
        contextMsg = "Minor anomalies detected (e.g. missing camera data), but evidence is weak.";
    } else {
        // NO INDICATORS
        verdict.textContent = "No AI Indicators Found";
        verdict.classList.add('safe');
        confidenceBar.classList.add('low');
        confidencePercent = 5;
        contextMsg = "Metadata contains standard capture tags (Camera/Device) consistent with original media.";
        
        if (isVideo && !hasCamera) {
             contextMsg += " Note: Video container metadata is limited in-browser.";
        }
    }

    // Render
    confidenceBar.style.width = `${confidencePercent}%`;
    contextEl.textContent = contextMsg;

    if (signals.length === 0 && score === 0) {
        signals.push("No specific AI markers detected.");
    }
    
    signals.forEach(r => {
        const li = document.createElement('li');
        li.className = 'signal-item';
        li.textContent = `• ${r}`;
        signalsList.appendChild(li);
    });
}

// --- Utilities ---

function getVideoNativeMetadata(file) {
    return new Promise((resolve) => {
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.onloadedmetadata = () => {
            window.URL.revokeObjectURL(video.src);
            resolve({
                durationSec: video.duration,
                videoWidth: video.videoWidth,
                videoHeight: video.videoHeight,
                MIMEType: file.type
            });
        };
        video.onerror = () => resolve({});
        video.src = URL.createObjectURL(file);
    });
}

function formatBytes(bytes, decimals = 2) {
    if (!+bytes) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function formatDuration(seconds) {
    if (!seconds) return "";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return h > 0 ? `${h}h ${m}m ${s}s` : `${m}m ${s}s`;
}

function switchView(viewName) {
    const views = {
        upload: document.getElementById('upload-view'),
        loading: document.getElementById('loading-view'),
        results: document.getElementById('results-view')
    };
    Object.values(views).forEach(el => el.classList.remove('active'));
    views[viewName].classList.add('active');
}

function resetApp() {
    document.getElementById('file-input').value = '';
    switchView('upload');
    // Clear data
    document.getElementById('camera-data').innerHTML = '';
    document.getElementById('tech-data').innerHTML = '';
    document.getElementById('ai-section').style.display = 'none';
}
